#!/usr/bin/env python3
"""Structured-output conformance harness — Toolkit Labs.

Measures, for a set of LLM endpoints, how often the returned text is (a) parseable
JSON and (b) valid against a given JSON Schema, in two modes:

  plain   — the schema is pasted into the prompt; no provider structured-output feature
  native  — the provider's own structured-output feature carries the schema

Stdlib only. No third-party packages, no network dependency beyond the two provider
endpoints. Keys are read from a .env file BY NAME and never printed.

  python3 harness.py --selftest          # validator + extractor tests, no network
  python3 harness.py --run --out DIR     # full matrix (spends free-tier quota)
  python3 harness.py --score DIR         # rebuild matrix.csv/json from raw-runs.jsonl

Licence of this harness: CC0-1.0 (public domain dedication). See README.md.
"""
import argparse, json, os, re, sys, time, hashlib, threading, urllib.request, urllib.error
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ENV_PATH = os.environ.get("TL_ENV", os.path.join(HERE, ".env"))  # set TL_ENV to point elsewhere
UA = "toolkitlabs-conformance/1.0"

# ----------------------------------------------------------------------------- validator
SUPPORTED = {"type", "properties", "required", "additionalProperties", "enum",
             "items", "minItems", "maxItems", "minimum", "maximum", "pattern", "anyOf"}

class SchemaUnsupported(Exception):
    """Raised when a schema uses a keyword this validator does not implement.
    This BLOCKS: silently ignoring a keyword would inflate every pass rate."""

def _is_int(v):
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return v.is_integer()
    return False

def _type_ok(v, t):
    if t == "object":  return isinstance(v, dict)
    if t == "array":   return isinstance(v, list)
    if t == "string":  return isinstance(v, str)
    if t == "integer": return _is_int(v)
    if t == "number":  return (isinstance(v, (int, float)) and not isinstance(v, bool))
    if t == "boolean": return isinstance(v, bool)
    if t == "null":    return v is None
    raise SchemaUnsupported("unknown type: %r" % (t,))

def validate(value, schema, path="$", errs=None):
    """Return a list of error strings. Empty list == valid.
    Draft 2020-12 subset: exactly the keywords in SUPPORTED."""
    if errs is None:
        errs = []
    unknown = set(schema) - SUPPORTED
    if unknown:
        raise SchemaUnsupported("unsupported keywords %s at %s" % (sorted(unknown), path))

    if "anyOf" in schema:
        for sub in schema["anyOf"]:
            if not validate(value, sub, path, []):
                break
        else:
            errs.append("%s: matches no anyOf branch" % path)
        return errs

    if "type" in schema:
        t = schema["type"]
        ts = t if isinstance(t, list) else [t]
        if not any(_type_ok(value, x) for x in ts):
            errs.append("%s: type %s, got %s" % (path, "|".join(ts), type(value).__name__))
            return errs

    if "enum" in schema and value not in schema["enum"]:
        errs.append("%s: %r not in enum" % (path, value))

    if isinstance(value, dict):
        for k in schema.get("required", []):
            if k not in value:
                errs.append("%s: missing required %r" % (path, k))
        props = schema.get("properties", {})
        if schema.get("additionalProperties") is False:
            for k in value:
                if k not in props:
                    errs.append("%s: additional property %r" % (path, k))
        for k, sub in props.items():
            if k in value:
                validate(value[k], sub, "%s.%s" % (path, k), errs)

    if isinstance(value, list):
        if "minItems" in schema and len(value) < schema["minItems"]:
            errs.append("%s: %d items < minItems %d" % (path, len(value), schema["minItems"]))
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            errs.append("%s: %d items > maxItems %d" % (path, len(value), schema["maxItems"]))
        if "items" in schema:
            for i, it in enumerate(value):
                validate(it, schema["items"], "%s[%d]" % (path, i), errs)

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            errs.append("%s: %r < minimum %r" % (path, value, schema["minimum"]))
        if "maximum" in schema and value > schema["maximum"]:
            errs.append("%s: %r > maximum %r" % (path, value, schema["maximum"]))

    if isinstance(value, str) and "pattern" in schema:
        if re.search(schema["pattern"], value) is None:
            errs.append("%s: does not match pattern" % path)

    return errs

# ----------------------------------------------------------------------------- extraction
def parse_strict(text):
    """The WHOLE response, stripped of surrounding whitespace, is JSON."""
    try:
        return json.loads(text.strip()), None
    except Exception as e:
        return None, str(e)

def parse_lenient(text):
    """Strict, else a fenced block, else the first balanced {...} or [...] span.
    This is what a real consumer does, and scoring on it is stated in the README."""
    v, _ = parse_strict(text)
    if v is not None:
        return v, "strict"
    m = re.search(r"```(?:json)?\s*(.+?)\s*```", text, re.S)
    if m:
        try:
            return json.loads(m.group(1)), "fence"
        except Exception:
            pass
    for opener, closer in (("{", "}"), ("[", "]")):
        start = text.find(opener)
        while start != -1:
            depth, in_str, esc = 0, False, False
            for i in range(start, len(text)):
                c = text[i]
                if in_str:
                    if esc: esc = False
                    elif c == "\\": esc = True
                    elif c == '"': in_str = False
                    continue
                if c == '"': in_str = True
                elif c == opener: depth += 1
                elif c == closer:
                    depth -= 1
                    if depth == 0:
                        try:
                            return json.loads(text[start:i + 1]), "span"
                        except Exception:
                            break
            start = text.find(opener, start + 1)
    return None, None


# ----------------------------------------------------------------------------- sanitiser
# Providers accept a SUBSET of JSON Schema in their structured-output field. These two
# functions perform the minimum edit that makes a schema acceptable, and report exactly
# what was removed. Validation is ALWAYS against the ORIGINAL schema, never the sanitised
# one — the whole point is to measure whether the removed constraints still hold.
GOOGLE_DROP = {"additionalProperties", "pattern", "minimum", "maximum"}
GROQ_DROP = {"pattern", "minimum", "maximum"}

def sanitise(schema, provider, dropped=None):
    if dropped is None:
        dropped = set()
    drop = GOOGLE_DROP if provider == "google" else GROQ_DROP
    out = {}
    for k, v in schema.items():
        if k in drop:
            dropped.add(k)
            continue
        out[k] = v
    if "type" in out and isinstance(out["type"], list):
        ts = [t for t in out["type"] if t != "null"]
        if provider == "google":
            out["type"] = ts[0] if ts else "string"
            out["nullable"] = True
            dropped.add("type-array->nullable")
    if "properties" in out:
        out["properties"] = {k: sanitise(v, provider, dropped) for k, v in out["properties"].items()}
        if provider == "groq":
            # OpenAI-style strict mode: every property must appear in `required`,
            # and additionalProperties:false must be present on every object.
            if set(out.get("required", [])) != set(out["properties"]):
                dropped.add("required<-all-properties")
            out["required"] = list(out["properties"].keys())
            out["additionalProperties"] = False
    if "items" in out:
        out["items"] = sanitise(out["items"], provider, dropped)
    if "anyOf" in out:
        out["anyOf"] = [sanitise(x, provider, dropped) for x in out["anyOf"]]
    return out

def sanitise_report(schema, provider):
    d = set()
    s = sanitise(schema, provider, d)
    return s, sorted(d)

# ----------------------------------------------------------------------------- selftest
# Expected values below were written by hand from the schema text BEFORE this file
# was executed once. They are the acceptance test for the validator, not a snapshot.
SELFTEST = [
    ("s1_flat_scalars", {"title": "Dune", "author": "Frank Herbert", "year": 1965, "pages": 412}, True,  "canonical"),
    ("s1_flat_scalars", {"title": "Dune", "author": "Frank Herbert", "year": "1965", "pages": 412}, False, "year as string"),
    ("s1_flat_scalars", {"title": "Dune", "author": "Frank Herbert", "year": 1965, "pages": 412, "isbn": "x"}, False, "additionalProperties"),
    ("s1_flat_scalars", {"title": "Dune", "author": "Frank Herbert", "year": 1965}, False, "missing required"),
    ("s1_flat_scalars", {"title": "Dune", "author": "Frank Herbert", "year": 1965, "pages": 412.0}, True,  "412.0 is an integer in JSON Schema"),
    ("s1_flat_scalars", {"title": "Dune", "author": "Frank Herbert", "year": 1965, "pages": True}, False, "bool is not integer"),
    ("s2_enums_and_bounds", {"category": "bug", "priority": 1, "confidence": 1, "blocking": True}, True,  "maximum is inclusive"),
    ("s2_enums_and_bounds", {"category": "Bug", "priority": 1, "confidence": 0.9, "blocking": True}, False, "enum is case sensitive"),
    ("s2_enums_and_bounds", {"category": "bug", "priority": 0, "confidence": 0.9, "blocking": True}, False, "priority below minimum"),
    ("s3_nested_object", {"order_id": "A-7741", "customer": {"name": "Maria Alvarez", "address": {"street": "14 Rue de Rivoli", "city": "Paris", "postal_code": "75001", "country": "France"}}, "total": {"amount": 84.5, "currency": "EUR"}}, True, "canonical"),
    ("s3_nested_object", {"order_id": "A-7741", "customer": {"name": "Maria Alvarez", "address": {"street": "14 Rue de Rivoli", "city": "Paris", "country": "France"}}, "total": {"amount": 84.5, "currency": "EUR"}}, False, "missing nested required"),
    ("s4_array_of_objects", {"languages": [{"name": "C", "year": 1972, "paradigm": "procedural"}, {"name": "Python", "year": 1991, "paradigm": "multi_paradigm"}, {"name": "Haskell", "year": 1990, "paradigm": "functional"}]}, True, "canonical"),
    ("s4_array_of_objects", {"languages": [{"name": "C", "year": 1972, "paradigm": "procedural"}, {"name": "Python", "year": 1991, "paradigm": "multi_paradigm"}]}, False, "minItems"),
    ("s5_optional_and_null", {"name": "Dr. Yuki Tanaka", "email": "y.tanaka@example.jp", "phone": None}, True, "null allowed by type array"),
    ("s5_optional_and_null", {"name": "Dr. Yuki Tanaka", "email": "y.tanaka@example.jp", "phone": None, "city": "Kyoto"}, True, "optional property present"),
    ("s5_optional_and_null", {"name": "Dr. Yuki Tanaka", "email": "not-an-email", "phone": None}, False, "email pattern"),
    ("s5_optional_and_null", {"name": "Dr. Yuki Tanaka", "email": "y.tanaka@example.jp", "phone": 812345}, False, "phone integer"),
    ("s6_union_anyof", {"title": "Quarterly review", "location": "Lisbon office", "when": {"kind": "one_off", "date": "2026-03-17", "duration_minutes": 90}}, True, "one_off branch"),
    ("s6_union_anyof", {"title": "Quarterly review", "location": "Lisbon office", "when": {"kind": "recurring", "rrule": "FREQ=MONTHLY"}}, True, "recurring branch"),
    ("s6_union_anyof", {"title": "Quarterly review", "location": "Lisbon office", "when": {"kind": "one_off", "date": "17/03/2026", "duration_minutes": 90}}, False, "no branch matches"),
]
EXTRACT_TESTS = [
    ('{"a": 1}', {"a": 1}, "strict"),
    ('```json\n{"a": 1}\n```', {"a": 1}, "fence"),
    ('Here you go:\n{"a": [1,2]}\nHope that helps.', {"a": [1, 2]}, "span"),
    ('Sure! {"s": "a } brace in a string", "b": 2}', {"s": "a } brace in a string", "b": 2}, "span"),
    ('no json here at all', None, None),
]

def selftest(schemas):
    by_id = {s["id"]: s["schema"] for s in schemas}
    fails = []
    for sid, doc, want_valid, why in SELFTEST:
        errs = validate(doc, by_id[sid])
        got = not errs
        mark = "ok " if got == want_valid else "FAIL"
        if got != want_valid:
            fails.append("%s/%s want_valid=%s got=%s errs=%s" % (sid, why, want_valid, got, errs))
        print("  [%s] %-22s %-45s -> valid=%s" % (mark, sid, why, got))
    for text, want, want_how in EXTRACT_TESTS:
        got, how = parse_lenient(text)
        ok = (got == want) and (how == want_how)
        if not ok:
            fails.append("extract %r want=%r/%s got=%r/%s" % (text[:30], want, want_how, got, how))
        print("  [%s] extract %-30r -> %s via %s" % ("ok " if ok else "FAIL", text[:28], got, how))
    try:
        validate({}, {"type": "object", "propertyNames": {}})
        fails.append("unsupported-keyword guard did not fire")
        print("  [FAIL] unsupported keyword was silently ignored")
    except SchemaUnsupported as e:
        print("  [ok ] unsupported keyword blocks: %s" % e)
    print("\nSELFTEST: %d checks, %d failures" % (len(SELFTEST) + len(EXTRACT_TESTS) + 1, len(fails)))
    for f in fails:
        print("  FAILURE:", f)
    return 1 if fails else 0

# ----------------------------------------------------------------------------- providers
def load_env():
    env = {}
    with open(ENV_PATH) as fh:
        for ln in fh:
            ln = ln.strip()
            if ln and not ln.startswith("#") and "=" in ln:
                k, v = ln.split("=", 1)
                env[k.strip()] = v.strip().strip('"').strip("'")
    return env

def http_json(url, payload, headers, timeout=90):
    body = json.dumps(payload).encode()
    h = {"Content-Type": "application/json", "User-Agent": UA}
    h.update(headers or {})
    req = urllib.request.Request(url, data=body, headers=h, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return r.status, json.loads(raw.decode("utf-8", "replace")), len(raw)
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            j = json.loads(raw.decode("utf-8", "replace"))
        except Exception:
            j = {"_raw": raw.decode("utf-8", "replace")[:600]}
        return e.code, j, len(raw)
    except Exception as e:
        return "ERR", {"_exc": repr(e)[:300]}, 0

PROMPT_PLAIN = ("%s\n\nReturn ONLY a JSON object that validates against this JSON Schema. "
                "No prose, no markdown fence, no explanation.\n\nSCHEMA:\n%s")
PROMPT_NATIVE = "%s"

def call_gemini(key, model, task, schema, mode):
    url = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s" % (model, key)
    cfg = {"temperature": 0, "maxOutputTokens": 2048}
    dropped = []
    if mode in ("native", "native_sanitised"):
        sent = schema
        if mode == "native_sanitised":
            sent, dropped = sanitise_report(schema, "google")
        cfg["responseMimeType"] = "application/json"
        cfg["responseSchema"] = sent
        prompt = PROMPT_NATIVE % task
    else:
        prompt = PROMPT_PLAIN % (task, json.dumps(schema, indent=2))
    st, j, n = http_json(url, {"contents": [{"role": "user", "parts": [{"text": prompt}]}],
                               "generationConfig": cfg}, {})
    text = ""
    if st == 200:
        for c in j.get("candidates", []):
            for p in c.get("content", {}).get("parts", []):
                text += p.get("text", "")
    return st, text, n, j, dropped

def call_groq(key, model, task, schema, mode):
    url = "https://api.groq.com/openai/v1/chat/completions"
    payload = {"model": model, "temperature": 0, "seed": 20260820, "max_tokens": 2048,
               "messages": [{"role": "user", "content": PROMPT_PLAIN % (task, json.dumps(schema, indent=2))}]}
    dropped = []
    if mode in ("native", "native_sanitised"):
        sent = schema
        if mode == "native_sanitised":
            sent, dropped = sanitise_report(schema, "groq")
        payload["messages"] = [{"role": "user", "content": PROMPT_NATIVE % task}]
        payload["response_format"] = {"type": "json_schema",
                                      "json_schema": {"name": "answer", "strict": True, "schema": sent}}
    st, j, n = http_json(url, payload, {"Authorization": "Bearer " + key})
    text = ""
    if st == 200:
        try:
            text = j["choices"][0]["message"]["content"] or ""
        except Exception:
            text = ""
    return st, text, n, j, dropped

MODELS = [
    # (label, provider, api_model_id, key_name, min_seconds_between_calls)
    ("gemini-2.5-flash",      "google", "gemini-2.5-flash",      "GEMINI_API_KEY", 6.5),
    ("gemini-3.1-flash-lite", "google", "gemini-3.1-flash-lite", "GEMINI_API_KEY", 4.5),
    ("groq/openai-gpt-oss-20b",  "groq", "openai/gpt-oss-20b",   "GROQ_API_KEY",   2.2),
    ("groq/openai-gpt-oss-120b", "groq", "openai/gpt-oss-120b",  "GROQ_API_KEY",   2.2),
    ("groq/qwen3.6-27b",         "groq", "qwen/qwen3.6-27b",     "GROQ_API_KEY",   2.2),
]
TRIALS = 3
MODES = ["plain", "native", "native_sanitised"]

def run_matrix(schemas, outdir, trials=TRIALS):
    env = load_env()
    os.makedirs(outdir, exist_ok=True)
    raw_path = os.path.join(outdir, "raw-runs.jsonl")
    lock = threading.Lock()
    fh = open(raw_path, "w")
    started = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    def worker(label, provider, mid, keyname, gap):
        key = env.get(keyname)
        if not key:
            return
        for mode in MODES:
            for s in schemas:
                for trial in range(trials):
                    t0 = time.time()
                    fn = call_gemini if provider == "google" else call_groq
                    st, text, nbytes, j, dropped = fn(key, mid, s["task"], s["schema"], mode)
                    tries = 1
                    while st == 429 and tries <= 3:
                        time.sleep(20 * tries)
                        st, text, nbytes, j, dropped = fn(key, mid, s["task"], s["schema"], mode)
                        tries += 1
                    strict, strict_err = parse_strict(text)
                    lenient, how = parse_lenient(text)
                    if lenient is None:
                        errs, valid = ["response did not contain JSON"], False
                    else:
                        try:
                            errs = validate(lenient, s["schema"])
                            valid = not errs
                        except SchemaUnsupported as e:
                            fh.close()
                            raise
                    rec = {"model": label, "provider": provider, "api_model": mid, "mode": mode,
                           "schema": s["id"], "grade": s["grade"], "trial": trial,
                           "http_status": st, "resp_bytes": nbytes, "retries": tries - 1,
                           "seconds": round(time.time() - t0, 2),
                           "parsed_strict": strict is not None, "parsed_lenient": lenient is not None,
                           "extraction": how, "schema_valid": bool(valid),
                           "schema_keywords_dropped": dropped,
                           "errors": errs[:6],
                           "api_error": (json.dumps(j)[:400] if st != 200 else None),
                           "response_sha256": hashlib.sha256(text.encode()).hexdigest()[:16],
                           "response_chars": len(text)}
                    with lock:
                        fh.write(json.dumps(rec) + "\n")
                        fh.flush()
                        print("  %-26s %-6s %-22s t%d -> http=%s valid=%s" % (label, mode, s["id"], trial, st, valid))
                    dt = gap - (time.time() - t0)
                    if dt > 0:
                        time.sleep(dt)

    threads = [threading.Thread(target=worker, args=m) for m in MODELS]
    for t in threads: t.start()
    for t in threads: t.join()
    fh.close()
    meta = {"started_utc": started,
            "finished_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "trials_per_cell": trials, "modes": MODES,
            "models": [{"label": m[0], "provider": m[1], "api_model": m[2]} for m in MODELS],
            "schemas": [{"id": s["id"], "grade": s["grade"]} for s in schemas],
            "temperature": 0, "groq_seed": 20260820,
            "schemas_sha256": hashlib.sha256(open(os.path.join(HERE, "schemas.json"), "rb").read()).hexdigest(),
            "harness_sha256": hashlib.sha256(open(os.path.abspath(__file__), "rb").read()).hexdigest()}
    json.dump(meta, open(os.path.join(outdir, "run-meta.json"), "w"), indent=2)
    return raw_path

def score(outdir):
    recs = [json.loads(l) for l in open(os.path.join(outdir, "raw-runs.jsonl"))]
    meta = json.load(open(os.path.join(outdir, "run-meta.json")))
    cells = {}
    for r in recs:
        k = (r["model"], r["mode"], r["schema"])
        c = cells.setdefault(k, {"grade": r["grade"], "n": 0, "http_ok": 0, "strict": 0,
                                 "lenient": 0, "valid": 0, "errors": [], "statuses": {}})
        c["n"] += 1
        c["statuses"][str(r["http_status"])] = c["statuses"].get(str(r["http_status"]), 0) + 1
        if r["http_status"] == 200: c["http_ok"] += 1
        if r["parsed_strict"]: c["strict"] += 1
        if r["parsed_lenient"]: c["lenient"] += 1
        if r["schema_valid"]: c["valid"] += 1
        for e in r["errors"]:
            if e not in c["errors"]: c["errors"].append(e)
    rows = []
    for (model, mode, sid), c in sorted(cells.items()):
        rows.append({"model": model, "mode": mode, "schema": sid, "grade": c["grade"],
                     "trials": c["n"], "http_200": c["http_ok"],
                     "api_supported": c["http_ok"] > 0,
                     "strict_json_rate": round(c["strict"] / c["n"], 3),
                     "lenient_json_rate": round(c["lenient"] / c["n"], 3),
                     "schema_valid_rate": round(c["valid"] / c["n"], 3),
                     "http_statuses": ";".join("%s:%d" % kv for kv in sorted(c["statuses"].items())),
                     "first_errors": " | ".join(c["errors"][:3])})
    import csv
    csv_path = os.path.join(outdir, "matrix.csv")
    with open(csv_path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for r in rows: w.writerow(r)
    # coverage summary: cells attempted vs cells that produced a scoreable HTTP 200
    attempted = len(rows)
    answered = sum(1 for r in rows if r["api_supported"])
    per_model = {}
    for r in rows:
        m = per_model.setdefault(r["model"], {"cells": 0, "answered": 0, "valid": 0.0, "trials": 0, "valid_n": 0})
        m["cells"] += 1; m["trials"] += r["trials"]
        if r["api_supported"]:
            m["answered"] += 1
        m["valid_n"] += round(r["schema_valid_rate"] * r["trials"])
    summary = {"generated_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
               "run_meta": meta, "total_calls": len(recs),
               "cells_attempted": attempted, "cells_with_http_200": answered,
               "coverage_fill_rate": round(answered / attempted, 3),
               "per_model": {k: {"cells": v["cells"], "cells_answered": v["answered"],
                                 "calls": v["trials"],
                                 "schema_valid_rate": round(v["valid_n"] / v["trials"], 3)}
                             for k, v in sorted(per_model.items())},
               "rows": rows}
    json.dump(summary, open(os.path.join(outdir, "matrix.json"), "w"), indent=2)
    print("cells %d, answered %d, fill_rate %.3f, calls %d" %
          (attempted, answered, answered / attempted, len(recs)))
    for k, v in summary["per_model"].items():
        print("  %-26s cells_answered %2d/%2d  schema_valid_rate %.3f" %
              (k, v["cells_answered"], v["cells"], v["schema_valid_rate"]))
    return csv_path, os.path.join(outdir, "matrix.json")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--score", metavar="DIR")
    ap.add_argument("--out", default=os.path.join(HERE, "edition-1"))
    ap.add_argument("--trials", type=int, default=TRIALS)
    a = ap.parse_args()
    schemas = json.load(open(os.path.join(HERE, "schemas.json")))["schemas"]
    if a.selftest:
        sys.exit(selftest(schemas))
    if a.run:
        run_matrix(schemas, a.out, a.trials)
        score(a.out)
        return
    if a.score:
        score(a.score)
        return
    ap.print_help()

if __name__ == "__main__":
    main()
